﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace WebAPI_SmartInventory.Data.Models
{
    public class Usuarios
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public ObjectId Id { get; set; }

        [BsonElement("username")]
        public string Username { get; set; }

        [BsonElement("Email")]
        public string Email { get; set; }

        [BsonElement("Activo")]
        public decimal Activo { get; set; }

        [BsonElement("FechaCreacion")]
        public DateTime FechaCreacion { get; set; } = DateTime.Now;
    }
}
