﻿using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using WebAPI_SmartInventory.Data.Models;
using WebAPI_SmartInventory.Services;

namespace WebAPI_SmartInventory.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly ProductsService _productoService;

        public ProductsController(ProductsService productoService)
        {
            _productoService = productoService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var productos = await _productoService.GetAllAsync();
            return Ok(productos);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            if (!ObjectId.TryParse(id, out _))
            {
                return BadRequest("Invalid ID format. ID must be a valid ObjectId.");
            }

            var producto = await _productoService.GetByIdAsync(id);
            if (producto == null) return NotFound();
            return Ok(producto);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Products producto)
        {
            await _productoService.CreateAsync(producto);
            return CreatedAtAction(nameof(GetById), new { id = producto.Id }, producto);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, Products producto)
        {
            if (!ObjectId.TryParse(id, out _))
            {
                return BadRequest("Invalid ID format. ID must be a valid ObjectId.");
            }

            var existingProducto = await _productoService.GetByIdAsync(id);
            if (existingProducto == null) return NotFound();

            producto.Id = existingProducto.Id;
            await _productoService.UpdateAsync(id, producto);
            return Ok(producto);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            if (!ObjectId.TryParse(id, out _))
            {
                return BadRequest("Invalid ID format. ID must be a valid ObjectId.");
            }

            var producto = await _productoService.GetByIdAsync(id);
            if (producto == null) return NotFound();

            await _productoService.DeleteAsync(id);
            return NoContent();
        }
    }
}
