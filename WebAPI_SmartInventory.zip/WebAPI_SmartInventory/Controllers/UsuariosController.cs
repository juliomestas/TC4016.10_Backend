﻿using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using WebAPI_SmartInventory.Data.Models;
using WebAPI_SmartInventory.Services;

namespace WebAPI_SmartInventory.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsuariosController : ControllerBase
    {
        private readonly UsuariosService _usuarioService;

        public UsuariosController(UsuariosService usuarioService)
        {
            _usuarioService = usuarioService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var productos = await _usuarioService.GetAllAsync();
            return Ok(productos);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            if (!ObjectId.TryParse(id, out _))
            {
                return BadRequest("Invalid ID format. ID must be a valid ObjectId.");
            }

            var usuario = await _usuarioService.GetByIdAsync(id);
            if (usuario == null) return NotFound();
            return Ok(usuario);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Usuarios usuario)
        {
            await _usuarioService.CreateAsync(usuario);
            return CreatedAtAction(nameof(GetById), new { id = usuario.Id }, usuario);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, Usuarios usuario)
        {
            if (!ObjectId.TryParse(id, out _))
            {
                return BadRequest("Invalid ID format. ID must be a valid ObjectId.");
            }

            var existingProducto = await _usuarioService.GetByIdAsync(id);
            if (existingProducto == null) return NotFound();

            usuario.Id = existingProducto.Id;
            await _usuarioService.UpdateAsync(id, usuario);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            if (!ObjectId.TryParse(id, out _))
            {
                return BadRequest("Invalid ID format. ID must be a valid ObjectId.");
            }

            var usuario = await _usuarioService.GetByIdAsync(id);
            if (usuario == null) return NotFound();

            await _usuarioService.DeleteAsync(id);
            return NoContent();
        }
    }
}
